clc;clear;close all;

%set data for u = exp(-(x-0.5)^2), consider -10< x< 10

s=0.75;al=2*s;

cns=2^(2*s)*s*gamma(s+1/2)/(pi^(1/2)*gamma(1-s));
ue=@(x) exp(-(x-0.5).^2/2);%-sqrt(2*pi); 
%since the solution u decays fast, 
%so we may consider finite horizon to compute the source $f$ 
%and the neumann boundary $Nu$.
M=200; h=1/M; % set h, don't need to be too small.

M0=10000; radius = h*M0/2; %finite horizon to set f and Nu

row=set_stiff_v2(al,M0+2, h);
row0= zeros(2*M0+1,1); row0(1:M0+1)= row(end:-1:end-M0);
row0(M0+2:end)=row(2:end);

x_int= h:h:1-h;

%% set right-hand-side
ff = zeros(M-1,1);
for j=1:length(x_int)    
    xx=(x_int(j) - M0*h):h:(x_int(j) + M0*h);   
    ff(j) =  ue(xx)*row0;
end


del=[1,2,4,8,16];


delta = del(1);

xb_m=-16+h:h:0;

%% set boundary data


for j=1:1%length(del)    
    % set boundary data
    delta = del(j);  xb = -delta+h:h:0; Nu=zeros(length(xb),1);    
    for i = 1:length(xb)
        if i*h<1
           Nu(i) =  (-ue(xb(i)) + ue(x_int(1:i)))* row((length(xb)-i+2):(length(xb)+1));
        else
           Nu(i) = (-ue(xb(i))+ue(x_int)) * row((length(xb)-i+2):(length(xb)-i+2)+length(ff)-1);     
        end
    end
end






%h=1:100


 



% x=-10:0.1:10;
% 
% plot(x,ue(x))